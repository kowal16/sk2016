#include <stdio.h>
#include "fib.h"

int main(int argc, char ** argv){
	printf("Fib(%d) = %d\n", 10, fib(10));
	return 1;
}
